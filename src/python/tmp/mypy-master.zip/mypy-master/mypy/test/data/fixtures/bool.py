# builtins stub used in boolean-related test cases.

from typing import builtinclass

@builtinclass
class object:
    def __init__(self) -> None: pass

class type: pass
class tuple: pass
class function: pass
class bool: pass
class int: pass
class str: pass

True = bool()
False = bool()
