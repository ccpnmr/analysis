# Builtins stub used for some float/complex test cases.

class object:
    def __init__(self): pass

class type: pass
class function: pass
class int: pass
class float: pass
class complex: pass
class str: pass
