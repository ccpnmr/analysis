class object:
    def __init__(self) -> None: pass
class module: pass
class type: pass
class function: pass
class str: pass
