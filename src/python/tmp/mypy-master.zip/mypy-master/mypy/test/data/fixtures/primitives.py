# builtins stub with non-generic primitive types

class object:
    def __init__(self) -> None: pass

class type:
    def __init__(self, x) -> None: pass

class int: pass
class float: pass
class complex: pass
class bool: pass
class str: pass
class bytes: pass
class bytearray: pass
class tuple: pass
class function: pass
