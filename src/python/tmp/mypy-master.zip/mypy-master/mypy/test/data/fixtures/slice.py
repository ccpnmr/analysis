# Builtins stub used in slicing test cases.

class object:
    def __init__(self): pass

class type: pass
class tuple: pass
class function: pass

class int: pass
class str: pass

class slice: pass
