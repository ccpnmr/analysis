class ABCMeta: pass
abstractmethod = object()
