namedtuple = object()
