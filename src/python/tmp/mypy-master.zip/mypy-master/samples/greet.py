import typing


def greet(name: str) -> None:
    print('Hello', name)
greet('Jack')
greet('Jill')
greet('Bob')
